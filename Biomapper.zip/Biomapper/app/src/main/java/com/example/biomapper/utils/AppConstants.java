package com.example.biomapper.utils;


public class AppConstants {

    public static final String I18N = "i18n";
    public static final String LOCALE_LANGUAGE = "locale_language";
}
