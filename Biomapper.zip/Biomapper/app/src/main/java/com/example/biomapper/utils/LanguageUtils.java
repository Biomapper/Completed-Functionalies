package com.example.biomapper.utils;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.DisplayMetrics;

import com.example.biomapper.AppApplication;

import androidx.annotation.NonNull;


import java.lang.reflect.Field;
import java.util.Locale;


public class LanguageUtils {

    public static final String SYSTEM_LANGUAGE_TGA = "systemLanguageTag";

    /**
     * Update the config language configuration of the context, and perform reflection updates for the application
     */
    public static void updateLanguage(final Context context, Locale locale) {
        Resources resources = context.getResources();
        Configuration config = resources.getConfiguration();
        Locale contextLocale = config.locale;
        if (isSameLocale(contextLocale, locale)) {
            return;
        }
        DisplayMetrics dm = resources.getDisplayMetrics();
        config.setLocale(locale);
        if (context instanceof Application) {
            Context newContext = context.createConfigurationContext(config);
            try {
                //noinspection JavaReflectionMemberAccess
                Field mBaseField = ContextWrapper.class.getDeclaredField("mBase");
                mBaseField.setAccessible(true);
                mBaseField.set(context, newContext);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        resources.updateConfiguration(config, dm);
    }

    /**
     * Replace the Application context
     */
    public static void applyAppLanguage(@NonNull Activity activity) {
        Locale appLocale = getCurrentAppLocale();
        updateLanguage(AppApplication.getAppContext(), appLocale);
        updateLanguage(activity, appLocale);
    }

    /**
     * get system Local
     */
    public static Locale getSystemLocale() {
        return Resources.getSystem().getConfiguration().locale;
    }

    /**
     * Get app cache Locale
     */
    private static String getPrefAppLocaleLanguage() {
        SharedPreferences sp = AppApplication.getAppContext().getSharedPreferences(AppConstants.I18N, Context.MODE_PRIVATE);
        return sp.getString(AppConstants.LOCALE_LANGUAGE, "");
    }

    /**
     * Get app cache Locale
     */
    public static Locale getPrefAppLocale() {
        String appLocaleLanguage = getPrefAppLocaleLanguage();
        if (!TextUtils.isEmpty(appLocaleLanguage)) {
            if (SYSTEM_LANGUAGE_TGA.equals(appLocaleLanguage)) {
                return null;
            } else {
                return Locale.forLanguageTag(appLocaleLanguage);
            }
        }
        return Locale.ENGLISH;
    }

    /**
     * get Current App Locale
     */
    public static Locale getCurrentAppLocale() {
        Locale prefAppLocale = getPrefAppLocale();
        return prefAppLocale == null ? getSystemLocale() : prefAppLocale;
    }


    /**
     * save language
     */
    public static void saveAppLocaleLanguage(String language) {
        SharedPreferences sp = AppApplication.getAppContext().getSharedPreferences(AppConstants.I18N, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString(AppConstants.LOCALE_LANGUAGE, language);
        edit.apply();
    }


    /**
     * is to determine whether the locale is the same
     */
    private static boolean isSameLocale(Locale l0, Locale l1) {
        return equals(l1.getLanguage(), l0.getLanguage())
                && equals(l1.getCountry(), l0.getCountry());
    }

    /**
     * Return whether string1 is equals to string2.
     */
    public static boolean equals(final CharSequence s1, final CharSequence s2) {
        if (s1 == s2) return true;
        int length;
        if (s1 != null && s2 != null && (length = s1.length()) == s2.length()) {
            if (s1 instanceof String && s2 instanceof String) {
                return s1.equals(s2);
            } else {
                for (int i = 0; i < length; i++) {
                    if (s1.charAt(i) != s2.charAt(i)) return false;
                }
                return true;
            }
        }
        return false;
    }

}
